import React from "react";
import { View, Text, Modal, StyleSheet } from "react-native";

const modal = ({ vis, setVis, nav }) => {
  return (
    <>
      <Modal
        animationType="fade"
        transparent={true}
        visible={vis}
        onRequestClose={() => {
          Alert.alert("Modal has been closed.");
        }}
      >
        <View
          onStartShouldSetResponder={() => {
            setVis(false);
          }}
          style={{ flex: 1 }}
        >
          <View style={styles.modalView}>
            <Text style={{ fontSize: 14, color: "#85C8D5", marginBottom: 16 }}>
              My Stats
            </Text>
            <Text
              style={{ fontSize: 14, marginBottom: 16 }}
              onPress={() => {
                setVis(false);
                nav.navigate("Profile", { screen: "SettingsBilling" });
              }}
            >
              Billing
            </Text>
            <Text
              style={{ fontSize: 14, marginBottom: 16 }}
              onPress={() => {
                setVis(false);
                nav.navigate("Profile", { screen: "SettingsProfile" });
              }}
            >
              Profile
            </Text>
            <Text
              style={{ fontSize: 14, marginBottom: 16 }}
              onPress={() => {
                setVis(false);
                nav.navigate("Profile", { screen: "Settings" });
              }}
            >
              Settings
            </Text>
          </View>
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  modalView: {
    alignSelf: "flex-end",
    top: 80,
    right: 25,
    width: 164,
    height: 164,
    backgroundColor: "white",
    borderRadius: 4,
    padding: 20,
    alignItems: "flex-start",
  },
});

export default modal;
